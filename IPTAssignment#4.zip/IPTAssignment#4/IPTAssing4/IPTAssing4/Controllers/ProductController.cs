﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;
using System.Web.Mvc.Ajax;
using IPTAssing4.Models;
using IPTAssing4.Controllers;
using Grid;
using GridMvc;
using GridMvc.Pagination;

using GridMvc.Sorting;

namespace IPTAssing4.Controllers
{
    public class ProductController : Controller
    {
        FinalDBEntities db = new FinalDBEntities();


        // GET: Product
        public ActionResult Index(string searchBy,string search, int? pageNumber,string sortBy)
        {
            ViewBag.SortProductNameParameter = string.IsNullOrEmpty(sortBy) ? "productName Order" : "  ";

         
            ViewBag.SortProductPriceLowtohighParameter = sortBy == " ProductPrice" ? "productPrice (Low to high) Order" : "  ";
            ViewBag.SortProductPricehightolowParameter = sortBy == " ProductPrice" ? "productPrice (high to low) Order" : "  ";

            var productname = db.Products.AsQueryable();

            List<Product> myProduct = new List<Product>();
            if (searchBy == "ProductName")

                
            {
                productname = productname.Where(x => x.ProductName.Contains(search) || search == null);
                return View(db.Products.Where(x => x.ProductName.Contains(search) || search == null).ToList().ToPagedList(pageNumber ?? 1, 5));
            }
            else if (searchBy == "ProductDescription")
            {
                productname = productname.Where(x => x.ProductDescription.Contains(search) || search == null);
                return View(db.Products.Where(p => p.ProductDescription.Contains(search) || search == null).ToList().ToPagedList(pageNumber ?? 1, 5));
            }

            else if (searchBy == "ProductPrice")
            {
                productname = productname.Where(x => x.ProductPrice.Equals(search) || search == null);
                return View(db.Products.Where(p => p.ProductPrice.Equals(search) || search == null).ToList().ToPagedList(pageNumber ?? 1, 5));
            }



            else if (searchBy == "CategoryName")
            {
                productname = productname.Where(y => y.Category.CategoryName.Contains(search) || search == null);
                 return View(db.Products.Where(y => y.Category.CategoryName.Contains(search) || search == null).ToList().ToPagedList(pageNumber ?? 1, 5));
            }

            switch (sortBy)
            {
                case "productName order":
                    productname = productname.OrderByDescending(x => x.ProductName);
                    break;

                case "productPrice(Low to high) Order":
                    productname = productname.OrderByDescending(x => x.ProductPrice);
                    break;

                case "productPrice(high to low) Order":
                    productname = productname.OrderBy(x => x.ProductPrice);
                    break;
                default:
                    productname = productname.OrderBy(x => x.ProductName);
                    break;
            }
return View(db.Products.ToList().ToPagedList(pageNumber ?? 1, 7));
            



        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
